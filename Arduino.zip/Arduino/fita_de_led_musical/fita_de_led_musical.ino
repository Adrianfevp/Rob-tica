#include "fix_fft.h"
#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
#include <avr/power.h>
#endif
#include <stdint.h>
#include <math.h>

// Definições das fitas
#define strip1_Pin 8             //  Pino de sinal da Fita
const int strip1_NumLeds = 80;   //  Número de Leds

Adafruit_NeoPixel strip1 = Adafruit_NeoPixel(strip1_NumLeds, strip1_Pin, NEO_GRB + NEO_KHZ800);

//  Variável de brilho geral
const float valBrightnessAll = 200;

// Variáveis de Cores
uint32_t white = strip1.Color(255, 255, 255);
uint32_t blue = strip1.Color(0, 0, 255);
uint32_t red = strip1.Color(255, 0, 0);
uint32_t green = strip1.Color(0, 255, 0);
uint32_t orange = strip1.Color(255, 153, 0);
uint32_t purple = strip1.Color(255, 0, 255);
uint32_t pink = strip1.Color(255, 153, 255);
uint32_t yellow = strip1.Color(255, 255, 0);
uint32_t gold = strip1.Color(153, 153, 0);
uint32_t cyan = strip1.Color(0, 255, 255);
uint32_t black = strip1.Color(0, 0, 0);
uint8_t r, g, b;
uint32_t AliceBlue = 0xF0F8FF;
uint32_t Chocolate = 0xD2691E;
uint32_t selColor;

// Variáveis para aquisição do áudio
#define SAMPLES 128   // número de amostras do sinal de áudio DEVE SER EM POTÊNCIA DE 2
#define AUDIO A0      // Pino de entrada do sinal de áudio
char im[SAMPLES];
char data[SAMPLES];
int barht[SAMPLES];
int ledVolume;
int selFreq;
int micValue = 0;
int ledsLights = 0;
uint16_t j, n;

void setup() {

  // Inicia Fita
  strip1.begin();
  strip1.show();

  // Inicia Brilho
  strip1.setBrightness(valBrightnessAll);

  //Debug
  Serial.begin(115200);
  Serial.println("Serial 1 Inicializado\n");

}

void loop() {
  
  int i, m;
  int val;

  // Faz aquisição do sinal de áudio
  for (i = 0; i < SAMPLES; i++) {
    val = analogRead(AUDIO); // 0-1023
    data[i] = (char)(val / 4 - 128); // store as char
    im[i] = 0; // init all as 0
  }

  // Processa FFT da aquisição e processa dados adquiridos
  fix_fft(data, im, 7, 0);

  for (i = 0; i < SAMPLES / 2; i++) {
    barht[i] = (int)sqrt(data[i] * data[i] + im[i] * im[i]);
  }
  for (i = 0, m = 0; i < SAMPLES / 2; i++, m += 2) {
    barht[i] = barht[m] + barht[m + 1];
  }

  // Converte valores de intensidade de frequência para alterar cores, 6 e 5 são frequencias próximas da voz, pode alterar para tentar alterar efeitos
  n = barht[6];
  j = barht[5];
  n = map(n, 0, 50, 1, 255);
  j = map(j, 0, 50, 1, 255);
  selColor = Wheel((n + j) & 255);  // Se desejar cor fixa, alterar este comando para cor desejada, ex.: selColor = red;
  
  // Seleciona faixa de frequência baixa com maior intensidade para VU
  if (barht[0] >= barht[1] || barht[0] >= barht[2]) selFreq = barht[0];
  if (barht[1] >= barht[0] || barht[1] >= barht[2]) selFreq = barht[1];
  if (barht[2] >= barht[0] || barht[2] >= barht[1]) selFreq = barht[2];
  ledVolume = map(selFreq, 0, 50, 1, strip1_NumLeds);

  // Acende Leds conforme intensidade da frequência
  for (int i = 0; i < ledVolume ; i++) {
    strip1.setPixelColor(i, selColor);
  }
  for (int i = ledVolume; i < strip1_NumLeds ; i++) {
    strip1.setPixelColor(i, black);
  }
  strip1.show();
  
}

// Função para rodar cores conforme altera frequência
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if (WheelPos < 85) {
    return strip1.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  }
  if (WheelPos < 170) {
    WheelPos -= 85;
    return strip1.Color(0, WheelPos * 3, 255 - WheelPos * 3);
  }
  WheelPos -= 170;
  return strip1.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}
