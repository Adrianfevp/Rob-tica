// Defina o pino onde o sensor está conectado
int sensorPin = 2; // Você pode mudar para o pino que estiver usando
int sensorValue = 0;
int sensorPin1 = 3; // Você pode mudar para o pino que estiver usando
int sensorValue1 = 0;
int sensorPin2 = 4; // Você pode mudar para o pino que estiver usando
int sensorValue2 = 0;
int sensorPin3 = 5; // Você pode mudar para o pino que estiver usando
int sensorValue3 = 0;
int sensorPin4 = 6; // Você pode mudar para o pino que estiver usando
int sensorValue4 = 0;
int sensorPin5 = 7; // Você pode mudar para o pino que estiver usando
int sensorValue5 = 0;
int sensorPin6 = 8; // Você pode mudar para o pino que estiver usando
int sensorValue6 = 0;
int sensorPin7 = 9; // Você pode mudar para o pino que estiver usando
int sensorValue7 = 0;

void setup() {
  Serial.begin(9600);  // Inicia a comunicação serial
  pinMode(sensorPin, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin1, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin2, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin3, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin4, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin5, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin6, INPUT);  // Configura o pino como entrada
  pinMode(sensorPin7, INPUT);  // Configura o pino como entrada
}

void loop() {
  sensorValue = digitalRead(sensorPin);  // Lê o valor do sensor
  Serial.println(sensorValue);  // Exibe o valor no Serial Monitor
  sensorValue1 = digitalRead(sensorPin1);  // Lê o valor do sensor
  Serial.println(sensorValue1);  // Exibe o valor no Serial Monitor
  sensorValue2 = digitalRead(sensorPin2);  // Lê o valor do sensor
  Serial.println(sensorValue2);  // Exibe o valor no Serial Monitor
  sensorValue3 = digitalRead(sensorPin3);  // Lê o valor do sensor
  Serial.println(sensorValue3);  // Exibe o valor no Serial Monitor
  sensorValue4 = digitalRead(sensorPin4);  // Lê o valor do sensor
  Serial.println(sensorValue4);  // Exibe o valor no Serial Monitor
  sensorValue5 = digitalRead(sensorPin5);  // Lê o valor do sensor
  Serial.println(sensorValue5);  // Exibe o valor no Serial Monitor
  sensorValue6 = digitalRead(sensorPin6);  // Lê o valor do sensor
  Serial.println(sensorValue6);  // Exibe o valor no Serial Monitor
  sensorValue7 = digitalRead(sensorPin7);  // Lê o valor do sensor
  Serial.println(sensorValue7);  // Exibe o valor no Serial Monitor
  delay(500);  // Atraso para facilitar a leitura
}
