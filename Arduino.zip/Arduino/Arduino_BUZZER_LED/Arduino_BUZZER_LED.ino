
const int led1 = 11;    
const int led2 = 10;  
const int buzzerPin = 9;

void setup() {
  pinMode(led1, OUTPUT);  
  pinMode(led2, OUTPUT);  
  pinMode(buzzerPin, OUTPUT); 
}

void loop() {

  digitalWrite(led1, HIGH);   
  digitalWrite(led2, LOW);   
  tone(buzzerPin, 1500);     
  delay(500);                 
  noTone(buzzerPin);        
  digitalWrite(led1, LOW);    
  digitalWrite(led2, HIGH);
  tone(buzzerPin, 1400);    
  delay(500);                 
}
