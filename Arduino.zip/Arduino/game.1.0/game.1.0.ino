#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Fonts/FreeSans9pt7b.h>
 
// Definição do display
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET 4
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
 
// Conexoes
#define BUZZER 11
#define EIXOY A1 // Eixo Y do joystick
#define BOTAOB 3 // Botão do joystick ATIRA
#define BOTAOE 2 // Botão do joystick ATIRA

 
// Notas musicais
const int c = 261;
const int d = 294;
const int e = 329;
const int f = 349;
const int g = 391;
const int gS = 415;
const int a = 440;
const int aS = 455;
const int b = 466;
const int cH = 523;
const int cSH = 554;
const int dH = 587;
const int dSH = 622;
const int eH = 659;
const int fH = 698;
const int fSH = 740;
const int gH = 784;
const int gSH = 830;
const int aH = 880;

const unsigned char PROGMEM inimigo []= {
	0x0e, 0x50, 0x25, 0x84, 0x7c, 0x2e, 0x07, 0xe0, 0x8f, 0xf1, 0x5f, 0xfa, 0x9e, 0x79, 0x5f, 0x3e, 
	0x5d, 0x3c, 0x9e, 0x79, 0x5f, 0xfb, 0xef, 0xf7, 0x47, 0xe2, 0x70, 0x06, 0x24, 0xe4, 0x0a, 0x50
};

// Imagem do nave
const unsigned char PROGMEM nave [] = {
  0x00, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x3F, 0xF0, 0x3C, 0x00, 0x3C, 0x00, 0xFF, 0x00, 0x7F, 0xFF,
  0x7F, 0xFF, 0xFF, 0x00, 0x3C, 0x00, 0x3C, 0x00, 0x1F, 0xF0, 0x1C, 0x00, 0x00, 0x00, 0x00, 0x00
};
 
// Imagem do thiago na tela inicial
const unsigned char PROGMEM thiago [] = {
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0xc0, 0x00, 0x00, 0x00, 0x80, 0x00, 
	0x20, 0x00, 0x00, 0x02, 0x00, 0x00, 0x18, 0x00, 0x00, 0x04, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x08, 
	0x00, 0x00, 0x06, 0x00, 0x00, 0x10, 0x30, 0x00, 0x04, 0x00, 0x00, 0x20, 0xfc, 0x00, 0x04, 0x00, 
	0x00, 0x01, 0xfe, 0x00, 0x04, 0x00, 0x00, 0x03, 0xff, 0x00, 0x04, 0x00, 0x00, 0x03, 0xff, 0x00, 
	0x04, 0x00, 0x00, 0x07, 0xff, 0x80, 0x04, 0x00, 0x00, 0x87, 0xff, 0xe0, 0x00, 0x00, 0x00, 0x87, 
	0xff, 0xfc, 0x00, 0x00, 0x00, 0x87, 0xff, 0xff, 0x00, 0x00, 0x00, 0x87, 0xff, 0xff, 0x82, 0x00, 
	0x00, 0x06, 0xff, 0xff, 0xc2, 0x00, 0x00, 0x0c, 0x07, 0xf0, 0x42, 0x00, 0x00, 0x08, 0x07, 0xe0, 
	0x02, 0x00, 0x00, 0x0b, 0x03, 0xc0, 0x02, 0x00, 0x00, 0x4c, 0x9f, 0x80, 0x02, 0x00, 0x00, 0x0f, 
	0xbf, 0xf8, 0x02, 0x00, 0x00, 0x5f, 0xff, 0xf9, 0x02, 0x00, 0x00, 0x4f, 0xff, 0xff, 0x60, 0x00, 
	0x00, 0x5f, 0xff, 0xff, 0xe4, 0x00, 0x00, 0x5f, 0xff, 0xff, 0xe8, 0x00, 0x00, 0x7f, 0xff, 0xff, 
	0xc8, 0x00, 0x00, 0x6f, 0xff, 0xff, 0xc8, 0x00, 0x00, 0x6f, 0xfb, 0x7f, 0xc8, 0x00, 0x00, 0x2f, 
	0xfb, 0x7f, 0xc8, 0x00, 0x00, 0x1f, 0xe0, 0x3f, 0xd0, 0x00, 0x00, 0x1f, 0x80, 0x0f, 0xe0, 0x00, 
	0x00, 0x1f, 0x1f, 0x07, 0xa0, 0x00, 0x00, 0x1f, 0x7f, 0x87, 0xa0, 0x00, 0x00, 0x1f, 0xff, 0xd3, 
	0x00, 0x00, 0x00, 0x1f, 0xff, 0xfe, 0x00, 0x00, 0x00, 0x07, 0xf8, 0x7c, 0x40, 0x00, 0x00, 0x0f, 
	0xff, 0xfc, 0x40, 0x00, 0x00, 0x03, 0xff, 0xf8, 0x80, 0x00, 0x00, 0x05, 0xff, 0xe1, 0x80, 0x00, 
	0x00, 0x02, 0x7f, 0xc1, 0x00, 0x00, 0x00, 0x03, 0x7f, 0x81, 0x00, 0x00, 0x00, 0x03, 0x80, 0x03, 
	0x00, 0x00, 0x00, 0x03, 0xc0, 0x0f, 0x80, 0x00, 0x00, 0x03, 0xf0, 0x1e, 0xa0, 0x00, 0x00, 0x03, 
	0xff, 0xfe, 0x90, 0x00, 0x00, 0x03, 0xff, 0xff, 0xc0, 0x00, 0x08, 0x03, 0xff, 0xff, 0x82, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};
 
// Variaveis de controle do jogo
int pontos = 0;
int vidas = 5;
int nivel = 1;
unsigned long inicio = 0;   // início do jogo atual
unsigned long tempo = 0;    // instante atual
unsigned long tininiv = 0;  // quando o nível atual começou
 
// tiros do nave
// obs: no display o eixo x é vertical e o eixo y é horizontal
int xw_tirox = 0;          // posição vertical do tiro do nave
int xw_tiroy = 0;          // posição horizontal do tiro do nave
bool xw_atirando = false;  // true se tiro do nave no display
 
// tiros da estrela da morte
bool ds_armartiro = true;       // estrela da morte deve programar atirar
unsigned long ds_horatiro = 0;  // quando vai atirar
int ds_veltiros = 3;            // velocidade do tiro da estrela da morte
int ds_tiros = 0;               // numero de tiros no display
int ds_tirox[4] = { 95, 95, 95, 95 };
int ds_tiroy[4] = { 0, 0, 0, 0 };
 
// posição (vertical) do nave
int xw_x = 30;   
 
// posição da estrela da morte
int ds_dir = 0;                 // direção da movimentação
int ds_y = 95;                  // posição horizontal da estrela da morte
int ds_x = 8;                   // posição vertical da estrela da morte
int ds_velx = 1;                // velocidade vertical da estrela da morte
int ds_diametro = 10;           // diametro da estrela da morte
 
// Iniciação
void setup()   {
 
  pinMode(BOTAOB, INPUT_PULLUP); // Configura o botão B do joystick
  pinMode(BOTAOE, INPUT_PULLUP); // Configura o botão B do joystick

  // Iniciar o display
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.display();
  
  display.clearDisplay();
  display.setTextSize(0);
  display.drawBitmap(0, 0, thiago, 48, 64, 1);
  display.setFont(&FreeSans9pt7b);
  display.setTextSize(1); // Define o tamanho da fonte menor (0 equivale ao padrão pequeno)
  display.setTextColor(WHITE);
  display.setCursor(50, 20);
  display.println("THIAGO");
  display.setFont();
  display.setCursor(50, 23);
  display.setTextSize(0);
  display.println("Edition");
  display.setFont(&FreeSans9pt7b);
  display.setTextSize(0); // Mantém o tamanho pequeno para os outros textos
  display.setCursor(50, 45);
  display.println("SPACE");
  display.setFont();
  display.setCursor(50, 48);
  display.println("ship ");

  display.display();

  // Marcha imperial
  delay(300);
  beep(a, 500);
  beep(a, 500);
  beep(a, 500);
  beep(f, 350);
  beep(cH, 150);
  beep(a, 500);
  beep(f, 350);
  beep(cH, 150);
  beep(a, 650);
  delay(1000);
 
  inicio = millis();
}
 
// Loop principal
void loop() {
 
  if (vidas > 0) {
    display.clearDisplay();
    desenha_estrelas();
 
    // trata mudança de nível
    tempo = millis();
    if ((tempo - tininiv) > 50000) {
      tininiv = tempo;
      nivel = nivel + 1;
      ds_veltiros = ds_veltiros + 1; // tiros mais rápidos
      if (nivel % 2 == 0) {
        ds_velx = ds_velx + 1;
        ds_diametro = ds_diametro - 1;
      }
      tone(BUZZER, 500, 300);
      delay(300);
      tone(BUZZER, 1000, 200);
      delay(200);
    }
 
    // trata tiros da estrela da morte
    if (ds_armartiro) {
      ds_horatiro = millis() + random(400, 1200);
      ds_armartiro = false;
    }
    if (ds_horatiro < tempo)
    {
      ds_armartiro = true;
      ds_atira();
    }
    desenha_dstiros();
 
    int joystickY = analogRead(EIXOY);

    if (joystickY > 400 && xw_x >= 2) { // Movimento para cima (ajuste o limite, 400 é exemplo)
    xw_x -= 2;
    }
    if (joystickY < 600 && xw_x <= 46) { // Movimento para baixo (ajuste o limite, 600 é exemplo)
    xw_x += 2;
    }
    // trata botão atira
    if (digitalRead(BOTAOB) == 0 && !xw_atirando) {
      xw_atirando = true;
      xw_tiroy = 6;
      xw_tirox = xw_x + 8;
      tone(9, 1200, 20);
    }
    if (xw_atirando == 1) {
      // Move e desenha o tiro
      xw_tiroy = xw_tiroy + 8 ;
      display.drawLine(xw_tiroy, xw_tirox, xw_tiroy + 4, xw_tirox, 1);
    }
    if (xw_tiroy > 128) {
      xw_atirando = false;  // tiro saiu da tela
    }
 
    // desenha o nave
    display.drawBitmap(4, xw_x, nave, 16, 16, 1);
    display.drawBitmap(ds_y - 8, ds_x - 8, inimigo, 16, 16, 1);
    display.fillCircle(ds_y + 2, ds_x + 3, ds_diametro / 3, 0);
     
    // informações
    display.setTextSize(1);
    display.setTextColor(WHITE);
    display.setCursor(33, 57);
    display.println("pontos:");
    display.setCursor(74, 57);
    display.println(pontos);
    display.setCursor(33, 0);
    display.println("vidas:");
    display.setCursor(68, 0);
    display.println(vidas);
    display.setCursor(110, 0);
    display.println("N:");
    display.setCursor(122, 0);
    display.println(nivel);
    display.setCursor(108, 57);
    display.println((tempo-inicio) / 1000);
    display.display();
 
    // move a estrela da morte
    if (ds_dir == 0) {
      ds_x = ds_x + ds_velx;
    } else {
      ds_x = ds_x - ds_velx;
    }
    if (ds_x >= (64 - ds_diametro)) {
      ds_dir = 1;
    }
    if (ds_x <= ds_diametro) {
      ds_dir = 0;
    }
 
    // verifica se tiro acertou a estrela da morte
    if ((xw_tirox >= (ds_x - ds_diametro)) && (xw_tirox <= (ds_x + ds_diametro))) {
      if ((xw_tiroy > (ds_y - ds_diametro)) && (xw_tiroy < (ds_y + ds_diametro)))
      {
        xw_tiroy = -20;
        tone(9, 500, 20);
        pontos = pontos + 1;
        xw_atirando = false;
      }
    }
 
    // verifica se algum tiro da estrela da morte acertou o nave
    int pos = xw_x + 8;
    for (int i = 0; i < 4; i++) {
      if ((ds_tiroy[i] >= (pos - 8)) && (ds_tiroy[i] <= (pos + 8))) {
        if ((ds_tirox[i] < 12) && (ds_tirox[i] > 4)) {
          ds_tirox[i] = -50;
          ds_tiroy[i] = -50;
          tone(9, 100, 100);
          vidas = vidas - 1;
          if (i == 3) {
            ds_tiros = 0;
          }
          if (vidas == 0) {
            break;
          }
        }
      }
    }
 
    if (ds_tirox[3] < 1) {
      ds_tiros = 0;
      ds_tirox[3] = 200;
    }
 
    if (vidas == 0) {
      game_over();
    }
  } else {
     
    // aguarda apertar E para começar outro jogo
    if (digitalRead(BOTAOE) == 0)
    {
      tone(BUZZER, 280, 300);
      delay(300);
      tone(BUZZER, 250, 200);
      delay(200);
      tone(BUZZER, 370, 300);
      delay(300);
      reinicia();
      inicio = millis();
    }
  }
}
 
// Reinicia o jogo
void reinicia() {
  xw_tiroy = 0;
  xw_tirox = 0;
  xw_atirando = false;
  ds_x = 8;
  ds_dir = 0;
  pontos = 0;
 
  ds_veltiros = 3;
  ds_velx = 1;
  ds_diametro = 12;
 
  ds_armartiro = true;
  ds_horatiro = 0;
  ds_tiros = 0;
  for (int i = 0; i < 4; i++) {
    ds_tirox[i] = 95;
    ds_tiroy[i] = 0;
  }
 
  vidas = 5;
  nivel = 1;
  tempo = 0;
  tininiv = 0;
}
 
// Toca uma nota
void beep(int note, int duration) {
  tone(BUZZER, note, duration);
  delay(duration);
  noTone(BUZZER);
  delay(50);
}
 
// Desenha as estrelas ao fundo
void desenha_estrelas() { 
   display.drawPixel(20, 10, WHITE);  // Alpha Crucis (Acrux)
  display.drawPixel(35, 30, WHITE);  // Beta Crucis (Mimosa)
  display.drawPixel(70, 10, WHITE);  // Gamma Crucis (Gacrux)
  display.drawPixel(100, 25, WHITE); // Delta Crucis
  
  // Órion (Três Marias e mais algumas estrelas) - Distribuindo melhor
  display.drawPixel(25, 10, WHITE);  // Alnitak
  display.drawPixel(50, 25, WHITE);  // Alnilam
  display.drawPixel(75, 40, WHITE);  // Mintaka
  display.drawPixel(40, 40, WHITE);  // Saiph
  display.drawPixel(90, 35, WHITE);  // Bellatrix
  display.drawPixel(60, 50, WHITE);  // Meissa
  
  // Ursa Maior (6 estrelas principais) - Distribuindo melhor
  display.drawPixel(10, 10, WHITE);  // Alkaid
  display.drawPixel(20, 50, WHITE);  // Mizar
  display.drawPixel(40, 50, WHITE);  // Alioth
  display.drawPixel(70, 30, WHITE);  // Dubhe
  display.drawPixel(90, 15, WHITE);  // Merak
  display.drawPixel(110, 45, WHITE); // Phecda
}
// Estrela da morte atira
void ds_atira() {
  if (ds_tiros < 4) {
    ds_tirox[ds_tiros] = 95;
    ds_tiroy[ds_tiros] = ds_x;
    ds_tiros = ds_tiros + 1;
  }
}
 
// Desenha tiros da Estrela da morte
void desenha_dstiros() {
  for (int i = 0; i < ds_tiros; i++) {
    if (ds_tirox[i] >= 0) {
      display.drawCircle(ds_tirox[i], ds_tiroy[i], 2, 1);
      ds_tirox[i] = ds_tirox[i] - ds_veltiros;
    }
  }
}
 
// Desenha a tela de fim do jogo
void game_over() {
  tone(BUZZER, 200, 300);
  delay(300);
  tone(BUZZER, 250, 200);
  delay(200);
  tone(BUZZER, 300, 300);
  delay(300);
       
  display.clearDisplay();
  display.setFont();
  display.setTextSize(2);
  display.setTextColor(WHITE);
  display.setCursor(7, 10);
  display.println("GAME OVER!");
  display.setTextSize(1);
  display.setCursor(7, 30);
  display.println("pontos:");
  display.setCursor(50, 30);
  display.println(pontos);
  display.setCursor(7, 40);
  display.println("nivel:");
  display.setCursor(44, 40);
  display.println(nivel);
  display.setCursor(7, 50);
  display.println("tempo(s):");
  display.setCursor(66, 50);
  display.println((tempo - inicio) / 1000);
  display.display();
}