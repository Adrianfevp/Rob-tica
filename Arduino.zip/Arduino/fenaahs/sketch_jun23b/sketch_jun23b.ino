#include <DHT.h>

#define DHTPIN A5     // Digital pin connected to the DHT sensor
#define DHTTYPE DHT11   // DHT 11

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  // Read temperature as Celsius
  float t = dht.readTemperature();

  // Check if reading was successful
  if (isnan(t)) {
    Serial.println("Failed to read from DHT sensor!");
  } else {
    Serial.print("Temperature: ");
    Serial.print(t);
    Serial.println(" °C");
  }

  delay(2000); // Wait 2 seconds before taking the next reading
}
