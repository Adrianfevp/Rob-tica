#include <SoftwareSerial.h>

SoftwareSerial espSerial(6, 7);  // RX, TX (pinos do Arduino Uno)
int ledPin = 8;  // LED conectado ao pino 8 do Arduino

void setup() {
  Serial.begin(9600);       // Para o monitor serial do Arduino
  espSerial.begin(115200);  // Para o ESP-01

  pinMode(ledPin, OUTPUT);  // Configura o pino do LED como saída
  digitalWrite(ledPin, LOW); // Garante que o LED esteja apagado inicialmente

  Serial.println("Iniciando comunicação com o ESP-01...");

  // Configura o ESP-01 como ponto de acesso (AP)
  sendATCommand("AT+CWMODE=2", 1000);  // Configura o modo como ponto de acesso (AP)
  sendATCommand("AT+CIPMUX=1", 1000);  // Habilita multiplexer para conexões múltiplas
  sendATCommand("AT+CIFSR", 3000);    // Obtém o endereço IP
  sendATCommand("AT+CIPSERVER=1,80", 1000);  // Ativa o servidor na porta 80
}

void loop() {
  if (espSerial.available()) {
    String request = espSerial.readString();  // Lê os dados recebidos via Wi-Fi

    Serial.println("Requisição recebida:");
    Serial.println(request);  // Exibe a requisição no monitor serial

    // Verifica o que foi recebido e toma a ação
    if (request.indexOf("/led/on") != -1) {  // Comando para ligar o LED
      digitalWrite(ledPin, HIGH);
      Serial.println("LED Ligado");
      sendResponse("LED Ligado");
    } 
    else if (request.indexOf("/led/off") != -1) {  // Comando para desligar o LED
      digitalWrite(ledPin, LOW);
      Serial.println("LED Desligado");
      sendResponse("LED Desligado");
    } 
    else if (request.indexOf("/") != -1) {  // Comando para acessar a página principal
      sendWebPage();
    }
    else {
      // Caso o comando não seja reconhecido, enviar uma resposta genérica
      sendResponse("Comando não reconhecido");
    }
  }
}

void sendResponse(String message) {
  // Formata a resposta HTTP corretamente
  String response = "HTTP/1.1 200 OK\r\n";
  response += "Content-Type: text/plain\r\n";  // Pode ser text/html dependendo do conteúdo
  response += "Connection: close\r\n";
  response += "\r\n";  // Linha em branco para separar cabeçalho do corpo
  response += message;  // Corpo da resposta (o que será mostrado no navegador)

  // Envia o comando AT para enviar os dados
  String command = "AT+CIPSEND=0," + String(response.length()) + "\r\n";
  espSerial.print(command);  // Envia o comando de envio
  delay(100);  // Atraso para garantir que o comando de envio tenha sido processado

  espSerial.print(response);  // Envia a resposta HTTP
  delay(100);  // Atraso para garantir que a mensagem seja enviada completamente
}

// Função para enviar a página HTML com um botão para controlar o LED
void sendWebPage() {
  String page = 
    "HTTP/1.1 200 OK\r\n"
    "Content-Type: text/html\r\n"
    "Connection: close\r\n"
    "\r\n"
    "<!DOCTYPE html>"
    "<html>"
    "<head>"
    "<title>Controle do LED</title>"
    "<style>"
    "body { font-family: Arial, sans-serif; text-align: center; padding: 50px; color:white;}"
    "button { font-size: 20px; padding: 10px 20px; margin: 10px; cursor: pointer; }"
    "h1{color:black;}"
    "</style>"
    "</head>"
    "<body>"
    "<h1>Controle do LED</h1>"
    "<p><button onclick=\"location.href='/led/on'\">Ligar LED</button></p>"
    "<p><button onclick=\"location.href='/led/off'\">Desligar LED</button></p>"
    "</body>"
    "</html>";

  // Prepara o comando AT para enviar os dados
  String command = "AT+CIPSEND=0," + String(page.length()) + "\r\n";
  espSerial.print(command);  // Envia o comando de envio
  delay(100);  // Atraso para garantir que o comando de envio tenha sido processado

  espSerial.print(page);  // Envia a página HTML
  delay(100);  // Atraso para garantir que a mensagem seja enviada completamente
}

// Função para enviar comandos AT e esperar a resposta
void sendATCommand(String command, unsigned long delayTime) {
  Serial.print("Enviando comando: ");
  Serial.println(command);

  espSerial.println(command);  // Envia o comando para o ESP-01
  delay(delayTime);  // Aguarda o tempo necessário

  while (espSerial.available()) {
    String response = espSerial.readString();
    Serial.print("Resposta: ");
    Serial.println(response);  // Exibe a resposta do ESP-01
  }
  Serial.println();  // Linha em branco entre comandos
}
