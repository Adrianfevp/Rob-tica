const int TAMANHO_TABULEIRO = 3;

char tabuleiro[TAMANHO_TABULEIRO][TAMANHO_TABULEIRO] = {
  {'1', '2', '3'},
  {'4', '5', '6'},
  {'7', '8', '9'}
};

void setup() {
  Serial.begin(9600);
}

void loop() {
  imprimirTabuleiro();
  jogar();
  delay(1000);
}

void imprimirTabuleiro() {
  Serial.println("Jogo da Velha");
  Serial.println("-----------");
  for (int i = 0; i < TAMANHO_TABULEIRO; i++) {
    for (int j = 0; j < TAMANHO_TABULEIRO; j++) {
      Serial.print(tabuleiro[i][j]);
      Serial.print(" | ");
    }
    Serial.println();
    Serial.println("-----------");
  }
}

void jogar() {
  char jogador = 'X';
  int posicao;

  Serial.print("Jogador ");
  Serial.print(jogador);
  Serial.print(", escolha uma posicao (1-9): ");
  while (true) {
    while (!Serial.available()) {}
    posicao = Serial.parseInt();
    if (posicao >= 1 && posicao <= 9) {
      break;
    }
    Serial.println("Posicao invalida, tente novamente.");
  }

  int linha = (posicao - 1) / TAMANHO_TABULEIRO;
  int coluna = (posicao - 1) % TAMANHO_TABULEIRO;

  if (tabuleiro[linha][coluna] != 'X' && tabuleiro[linha][coluna] != 'O') {
    tabuleiro[linha][coluna] = jogador;
    jogador = (jogador == 'X') ? 'O' : 'X';
  } else {
    Serial.println("Posicao ja ocupada, tente novamente.");
  }

  verificarVitoria();
}

void verificarVitoria() {
  for (int i = 0; i < TAMANHO_TABULEIRO; i++) {
    if (tabuleiro[i][0] == tabuleiro[i][1] && tabuleiro[i][0] == tabuleiro[i][2]) {
      Serial.println("Jogador " + String(tabuleiro[i][0]) + " venceu!");
      resetarJogo();
    }
    if (tabuleiro[0][i] == tabuleiro[1][i] && tabuleiro[0][i] == tabuleiro[2][i]) {
      Serial.println("Jogador " + String(tabuleiro[0][i]) + " venceu!");
      resetarJogo();
    }
  }
  if (tabuleiro[0][0] == tabuleiro[1][1] && tabuleiro[0][0] == tabuleiro[2][2]) {
    Serial.println("Jogador " + String(tabuleiro[0][0]) + " venceu!");
    resetarJogo();
  }
  if (tabuleiro[0][2] == tabuleiro[1][1] && tabuleiro[0][2] == tabuleiro[2][0]) {
    Serial.println("Jogador " + String(tabuleiro[0][2]) + " venceu!");
    resetarJogo();
  }
}

void resetarJogo() {
  for (int i = 0; i < TAMANHO_TABULEIRO; i++) {
    for (int j = 0; j < TAMANHO_TABULEIRO; j++) {
      tabuleiro[i][j] = '1' + i * TAMANHO_TABULEIRO + j;
    }
  }
}
