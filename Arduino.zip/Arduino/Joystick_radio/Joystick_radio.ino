#include <SPI.h>
#include "nRF24L01.h"
#include "RF24.h"

#define CE_PIN   9
#define CSN_PIN 10
#define xAxis 14     // A0
#define yAxis 15     // A1

const uint64_t pipe = 0xE8E8F0F0E1LL;
RF24 radio(CE_PIN, CSN_PIN); 

int joystick[6];  

int botaoy    = 2;
int botaob = 3;
int botaoa  = 4;
int botaox  = 5;


void setup() {

  Serial.begin(9600);
  radio.begin();
  radio.openWritingPipe(pipe);
  radio.stopListening();
  
  pinMode(botaoy,INPUT_PULLUP);
  pinMode(botaob,INPUT_PULLUP);
  pinMode(botaoa,INPUT_PULLUP);
  pinMode(botaox,INPUT_PULLUP);
  
  digitalWrite(botaoy,LOW);
  digitalWrite(botaob,LOW);
  digitalWrite(botaoa,LOW);
  digitalWrite(botaox,LOW);

}

void loop() {
  
  joystick[0] = analogRead(xAxis);
  joystick[1] = analogRead(yAxis);
  joystick[2] = digitalRead(botaoy);
  joystick[3] = digitalRead(botaob);
  joystick[4] = digitalRead(botaoa);
  joystick[5] = digitalRead(botaox);
  
  radio.write( joystick, sizeof(joystick) );
  delay(20);

      Serial.print("X = ");
      Serial.print(analogRead(xAxis));
      Serial.print(" Y = ");  
      Serial.print(analogRead(yAxis));
      Serial.print(" cima = "); 
      Serial.print(digitalRead(botaoy));
      Serial.print(" direita = "); 
      Serial.print(digitalRead(botaob));
      Serial.print(" baixo = "); 
      Serial.print(digitalRead(botaoa));
      Serial.print(" esquerda = "); 
      Serial.println(digitalRead(botaox));

}
