const int ldrPin = 2;  // Pino onde o sensor digital está conectado
const int ledPin = 9;  // Pino onde o LED está conectado
void setup() {
  pinMode(ldrPin, INPUT); // Configura o pino do LDR como entrada
  pinMode(ledPin, OUTPUT); // Configura o pino do LED como saída
}

void loop() {
 int ldrValue = digitalRead(ldrPin); // Lê o valor do sensor LDR

  // Acende ou apaga o LED com base no valor lido
  if (ldrValue == HIGH) { // Se a luz estiver baixa
    digitalWrite(ledPin, HIGH); // Acende o LED
  } else {
    digitalWrite(ledPin, LOW);  // Apaga o LED
  }

  delay(100); // Atraso para evitar leituras muito rápidas
}
